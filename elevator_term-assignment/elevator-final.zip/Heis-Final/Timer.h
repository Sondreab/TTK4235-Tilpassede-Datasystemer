#pragma once

#define DURATION 3.0;

void timer_start(void);
void timer_stop(void);

int timer_isTimeOut();


